import React from 'react';

type Props = {};

const ViewProduct = (props: Props) => {
  return (
    <div>View Product Page</div>
  );
};

export default ViewProduct;