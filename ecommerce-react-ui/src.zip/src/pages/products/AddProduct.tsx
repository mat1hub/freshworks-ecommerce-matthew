import React from 'react';

type Props = {};

const AddProduct = (props: Props) => {
  return (
    <div>Add Product Page</div>
  );
};

export default AddProduct;