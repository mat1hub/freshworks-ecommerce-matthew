import { Outlet } from "react-router-dom";

const ProductPageLayout = () => {
  return (
    <><Outlet /></>
  );
};

export default ProductPageLayout;