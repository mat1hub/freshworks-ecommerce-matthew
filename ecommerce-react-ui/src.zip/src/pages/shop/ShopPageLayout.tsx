import { Outlet } from "react-router-dom";

const ShopPageLayout = () => {
  return (
    <><Outlet /></>
  );
};

export default ShopPageLayout;