import React from 'react';

type Props = {};

const ViewShop = (props: Props) => {
  return (
    <div>View Shop Page</div>
  );
};

export default ViewShop;