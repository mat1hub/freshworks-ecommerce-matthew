import React from 'react';

type Props = {};

const AddShop = (props: Props) => {
  return (
    <div>AddShop Page</div>
  );
};

export default AddShop;