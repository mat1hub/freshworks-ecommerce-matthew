import React from 'react';

type Props = {};

const Orders = (props: Props) => {
  return (
    <div>Orders Page</div>
  );
};

export default Orders;