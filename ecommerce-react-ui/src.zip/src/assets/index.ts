const assets = {
  images: {
    logo: require("./images/typescript-logo-240.png")
  }
};

export default assets;